#include<bits/stdc++.h>
using namespace std;
#define maxn 30
int a[maxn],c[maxn];
int main(){
	int n,x,ans=0;scanf("%d",&n);
	for(int i=1;i<=n;i++){scanf("%d",a+i);if(a[i]==a[i-1]+1)c[a[i-1]]=1;}
	for(int i=1;i<=n;i++)scanf("%d",&x),ans+=x;
	for(int i=1;i<n;i++)scanf("%d",&x),ans+=x*c[i];
	printf("%d",ans);
	return 0;
}
