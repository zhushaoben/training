#include<bits/stdc++.h>
using namespace std;
int main(){
	int n,pre=1000000,x,ans=0;scanf("%d",&n);
	for(int i=1;i<n;i++){
		scanf("%d",&x);
		ans+=min(x,pre);
		pre=x;
	}
	printf("%d",ans+pre);
	return 0;
}
