#include<bits/stdc++.h>
using namespace std;
#define maxn 100000
char s[maxn+5];
int main(){
	int n,k,w=0;scanf("%d%d%s",&n,&k,s+1);
	for(int i=2;i<=n;i++){
		if(s[i]!=s[i-1]){
			if(!w)w=1,k--;
			if(k==-1)break;
			s[i]^=30;
		}
		else w=0;
	}
	int ans=0;
	for(int i=1;i<=n;i++){
		if(s[i]=='L'&&s[i-1]=='L')ans++;
		if(s[i]=='R'&&s[i+1]=='R')ans++;
	}
	printf("%d",ans);
	return 0;
}
