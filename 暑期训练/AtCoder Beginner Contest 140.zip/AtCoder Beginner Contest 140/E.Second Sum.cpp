#include<bits/stdc++.h>
using namespace std;
#define maxn 100005
#define LL long long
int pos[maxn];
set<int>S;
int main(){
	int n,x;scanf("%d",&n);
	for(int i=1;i<=n;i++)scanf("%d",&x),pos[x]=i;
	S.insert(0),S.insert(n+1);
	LL ans=0;
	for(int i=n;i;i--){
		S.insert(pos[i]);
		auto j=S.find(pos[i]),k=j;
		int l0=*(--j),l1=(j!=S.begin())?*(--j):-1,r0=*(++k),r1=(++k)!=S.end()?*k:-1,w=0,x=pos[i];
//		printf("%d %d %d %d\n",l0,l1,r0,r1);
		if(l1!=-1)w+=(r0-x)*(l0-l1);
		if(r1!=-1)w+=(x-l0)*(r1-r0);
		ans+=1ll*i*w;
	}
	printf("%lld\n",ans);
	return 0;
}
