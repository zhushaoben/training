#include<bits/stdc++.h>
using namespace std;
int main(){
	int n,x,pre=-1,ans=0,now=0;scanf("%d",&n);
	for(int i=0;i<n;i++){
		scanf("%d",&x);
		if(x<=pre)now++;
		else now=0;
		pre=x,ans=max(ans,now);
	}
	printf("%d",ans);
	return 0;
}
