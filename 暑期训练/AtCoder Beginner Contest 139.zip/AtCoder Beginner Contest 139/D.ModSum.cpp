#include<bits/stdc++.h>
using namespace std;
int main(){
	int n;scanf("%d",&n);
	printf("%lld\n",1ll*(n-1)*n/2);
	return 0;
} 
