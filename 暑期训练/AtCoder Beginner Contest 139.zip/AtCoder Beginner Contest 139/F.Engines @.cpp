//����������󣬴�һ����ĳ�����䣨�ҷ�ΧС��180�ȣ� 
#include<bits/stdc++.h>
using namespace std;
#define maxn 105
struct Node{
	double key;int x,y;
	bool operator < (const Node &b)const{
		return key<b.key;
	}
}a[maxn];
int sx,sy;double ans;
double cal(int x,int y){
	sx+=x,sy+=y;
	return atan2(y,x);
}
int main(){
	int n;scanf("%d",&n);
	for(int i=0;i<n;i++)scanf("%d%d",&a[i].x,&a[i].y),a[i].key=cal(a[i].x,a[i].y);
	sort(a,a+n);
	for(int i=0;i<n;i++){
		int x=0,y=0;
		for(int j=i;;j++){
			j%=n;x+=a[j].x,y+=a[j].y;
			ans=max(sqrt(1ll*x*x+1ll*y*y),ans);
			if(x==sx&&y==sy)break;
		}
	}
	printf("%.20lf",ans);
	return 0;
}
