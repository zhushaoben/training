#include<bits/stdc++.h>
using namespace std;
int main(){
	int a,b;scanf("%d%d",&a,&b);
	printf("%d",(int)ceil(1.0*(b-1)/(a-1)));
	return 0;
}
