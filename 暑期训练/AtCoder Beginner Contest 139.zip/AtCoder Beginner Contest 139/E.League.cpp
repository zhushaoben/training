#include<bits/stdc++.h>
using namespace std;
#define maxn 500005
struct Edge{
	int next,to;
}edge[maxn*2];
int fi[maxn],se,in[maxn],day[maxn],vis[maxn],sum,ans;
inline void add_edge(int u,int v){
	edge[++se].to=v,edge[se].next=fi[u],fi[u]=se,in[v]++;
}
void dfs(int x){
	if(vis[x])return;
	ans=max(ans,day[x]),sum++,vis[x]=1;
	for(int i=fi[x];i;i=edge[i].next){
		int v=edge[i].to;
		in[v]--,day[v]=max(day[v],day[x]+1);
		if(!in[v])dfs(v);
	}
}
int main(){
	int n;scanf("%d",&n);
	for(int i=1;i<=n;i++){
		int u,v,pre=0;
		for(int j=1;j<n;j++){
			u=i;scanf("%d",&v);if(v<u)swap(u,v);
			v=(u-1)*(n+n-u)/2+v-u;
			if(pre)add_edge(pre,v);
			pre=v;
		}
	}
	n=(n-1)*n/2;
	for(int i=1;i<=n;i++)if(!in[i])dfs(i);
	if(sum==n)printf("%d\n",ans+1);
	else puts("-1");
	return 0;
}
