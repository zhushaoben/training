#include<bits/stdc++.h>
using namespace std;
char s[5],s1[5];int ans;
int main(){
	scanf("%s%s",s,s1);
	for(int i=0;i<3;i++)if(s[i]==s1[i])ans++;
	printf("%d\n",ans);
	return 0;
} 
