#include<bits/stdc++.h>
using namespace std;
#define maxn 100005
int a[maxn],n,k,b[maxn];
bool check(int x){
	for(int i=0;i<n;i++){
		b[i]=a[i]%x;
	}
	sort(b,b+n);
	int w=0,i;
	for(i=0;i<n;i++){
		w+=b[i];
		if(w>k)break;
	}
	for(w=0;i<n;i++){
		w+=x-b[i];
		if(w>k)return 0;
	}
	return 1;
}
int main(){
	int sum=0,x;scanf("%d%d",&n,&k);
	for(int i=0;i<n;i++)scanf("%d",a+i),sum+=a[i];x=sqrt(sum);
	for(int i=1;i<=x;i++){
		if(sum%i==0){
			if(check(sum/i)){
				printf("%d\n",sum/i);return 0;
			}
		}
	}
	for(int i=sqrt(sum);i>=1;i--){
		if(sum%i==0){
			if(check(i)){
				printf("%d\n",i);return 0;
			}
		}
	}
	return 0;
}
