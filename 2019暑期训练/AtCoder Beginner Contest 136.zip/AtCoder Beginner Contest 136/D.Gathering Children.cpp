#include<bits/stdc++.h>
using namespace std;
#define maxn 100005
char s[maxn];
int f[maxn][2];
int main(){
	scanf("%s",s+1);
	int i;
	for(i=1;s[i];i++){
		f[i][0]=1;
		if(s[i-1]=='R'&&s[i]=='R'){
			f[i][0]+=f[i-1][1],f[i][1]+=f[i-1][0];
		}
	}
	for(i=i-1;s[i];i--){
		if(s[i+1]=='L'&&s[i]=='L'){
			f[i][0]+=f[i+1][1],f[i][1]+=f[i+1][0];
		}
	}
	for(int i=1;s[i];i++){
		if(s[i]=='R'&&s[i+1]=='L'){
			printf("%d %d ",f[i][0]+f[i+1][1],f[i][1]+f[i+1][0]);i++;
		}
		else printf("0 ");
	}
	return 0;
}
