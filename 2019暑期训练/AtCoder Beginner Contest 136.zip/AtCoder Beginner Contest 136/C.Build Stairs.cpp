#include<bits/stdc++.h>
using namespace std;
#define maxn 100005
int a[maxn];
int main(){
	int n;scanf("%d",&n);
	for(int i=1;i<=n;i++){
		scanf("%d",a+i);
		if(a[i]>a[i-1])a[i]--;
		else if(a[i]<a[i-1]){
			puts("No");return 0;
		}
	}
	puts("Yes");
	return 0;
} 
