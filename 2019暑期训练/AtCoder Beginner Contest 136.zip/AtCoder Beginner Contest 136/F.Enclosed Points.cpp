#include<bits/stdc++.h>
using namespace std;
#define maxn 200005
#define mo 998244353
struct Node{
	int x,y;
	bool operator < (const Node &b)const{
		return x<b.x;
	}
}a[maxn];
int b[maxn],c[maxn],n,sum[maxn],lu[maxn],ld[maxn],ru[maxn],rd[maxn];long long pow2[maxn];
void read(){
	scanf("%d",&n);
	for(int i=0;i<n;i++){
		scanf("%d%d",&a[i].x,&a[i].y),b[i]=a[i].x,c[i]=a[i].y;
	}
	sort(b,b+n),sort(c,c+n);
	for(int i=0;i<n;i++){
		a[i].x=lower_bound(b,b+n,a[i].x)-b+1;
		a[i].y=lower_bound(c,c+n,a[i].y)-c+1;
	}
}
inline int lowbit(int x){
	return x&(-x);
}
int Sum(int x){
	int ans=0;
	while(x)ans+=sum[x],x^=lowbit(x);
	return ans;
}
void add(int x){
	while(x<=n)sum[x]++,x+=lowbit(x);
}
int main(){
	read();sort(a,a+n);
	for(int i=0;i<n;i++)lu[i]=Sum(a[i].y),ru[i]=i-lu[i],add(a[i].y);
	memset(sum,0,sizeof(sum));
	for(int i=n-1;i>=0;i--)ld[i]=Sum(a[i].y),rd[i]=n-i-1-ld[i],add(a[i].y);
	pow2[0]=1;for(int i=1;i<=n;i++)pow2[i]=(pow2[i-1]<<1)%mo;
	int ans=0;
	for(int i=0;i<n;i++){
		ans+=(pow2[n]-1-pow2[lu[i]+ld[i]]-pow2[ru[i]+rd[i]]-pow2[lu[i]+ru[i]]-pow2[ld[i]+rd[i]]
		+pow2[lu[i]]+pow2[ld[i]]+pow2[ru[i]]+pow2[rd[i]])%mo;
		ans%=mo;
	}
	printf("%d",(ans+mo)%mo);
	return 0;
}
