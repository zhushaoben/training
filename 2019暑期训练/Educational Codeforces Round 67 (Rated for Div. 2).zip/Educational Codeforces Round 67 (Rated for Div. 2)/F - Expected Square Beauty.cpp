#include<bits/stdc++.h>
using namespace std;
#define maxn 200005
#define mo 1000000007
#define LL long long
int n;
LL l[maxn],r[maxn],f[maxn],f1[maxn],ans;
void ex_gcd(LL &x,LL &y,int a,int b){//calc x*a+y*b=gcd(x,y)
	if(!b){x=1,y=0;return;}
	ex_gcd(x,y,b,a%b);
	int c=y;y=(-(a/b)*y+x)%mo;x=c;
}
int cal(LL a,LL b){//calculate (a/b)%mo
	if(a<=0)return 0;
	LL x,y;a%=mo,b%=mo;
	ex_gcd(x,y,b,mo);
	return a*x%mo;
}
int main(){
	scanf("%d",&n);
	for(int i=1;i<=n;i++)scanf("%d",l+i);
	for(int i=1;i<=n;i++)scanf("%d",r+i),r[i]++;r[0]=1;
	for(int i=2;i<=n;i++){
		if(min(r[i],r[i-1])>max(l[i],l[i-1]))f[i]=cal(min(r[i],r[i-1])-max(l[i],l[i-1]),(r[i]-l[i])*(r[i-1]-l[i-1]));
	}
	for(int i=1;i<n;i++){
//		if(min(r[i],min(r[i+1],r[i-1]))>max(l[i],max(l[i+1],l[i-1]))){
			f1[i]=1-f[i]-f[i+1]+
			cal(min(r[i],min(r[i+1],r[i-1]))-max(l[i],max(l[i+1],l[i-1])),
			((r[i]-l[i])*(r[i+1]-l[i+1])%mo)*(r[i-1]-l[i-1]));
			(ans+=f1[i]*2)%=mo;
//		}
	}
	l[0]=l[1]=r[n+1]=r[n+2]=0;
	for(int i=1;i<=n;i++)f[i]=(1-f[i])%mo,l[i]=(l[i-1]+f[i])%mo;
	for(int i=n;i;i--)r[i]=(r[i+1]+f[i])%mo;
	for(int i=1;i<=n;i++){
		(ans+=f[i]*(1+((i>2)?l[i-2]:0)+r[i+2]))%=mo;
	}
	printf("%d",(ans+mo)%mo);
	return 0;
} 
