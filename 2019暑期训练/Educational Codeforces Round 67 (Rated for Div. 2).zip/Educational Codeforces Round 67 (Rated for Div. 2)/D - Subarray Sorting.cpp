#include<bits/stdc++.h>
using namespace std;
#define maxn 300005
int a[maxn],b[maxn],fi[maxn],nex[maxn],la[maxn],mi[maxn*4];
inline void update(int x){
	mi[x]=min(mi[x<<1],mi[x<<1|1]);
}
void build(int l,int r,int x){
	if(l==r){
		mi[x]=a[l];return;
	}
	int mid=(l+r)>>1;
	build(l,mid,x<<1);build(mid+1,r,x<<1|1);update(x);
}
int R;
int query(int l,int r,int x){
	if(r<=R)return mi[x];
	int mid=(l+r)>>1,ans=maxn;
	ans=min(ans,query(l,mid,x<<1));
	if(R>mid)ans=min(ans,query(mid+1,r,x<<1|1));
	return ans;
}
void change(int l,int r,int x){
	if(l==r){
		mi[x]=maxn;return;
	}
	int mid=(l+r)>>1;
	if(R<=mid)change(l,mid,x<<1);
	else change(mid+1,r,x<<1|1);update(x);
}
inline void add(int x,int w){
	if(!la[w])fi[w]=x;
	nex[la[w]]=x,la[w]=x;
}
void work(){
	int n;scanf("%d",&n);memset(la,0,sizeof(int)*(n+10));memset(fi,0,sizeof(int)*(n+10)),memset(nex,0,sizeof(int)*(n+10));
	for(int i=1;i<=n;i++)scanf("%d",a+i),add(i,a[i]);
	build(1,n,1);
	for(int i=1;i<=n;i++)scanf("%d",b+i);
	for(int i=1;i<=n;i++){
		R=fi[b[i]],fi[b[i]]=nex[R];if((!R)||query(1,n,1)<b[i]){puts("NO");return;}
		change(1,n,1);
	}
	puts("YES");
}
int main(){
	int t;scanf("%d",&t);
	while(t--)work();
	return 0;
}
