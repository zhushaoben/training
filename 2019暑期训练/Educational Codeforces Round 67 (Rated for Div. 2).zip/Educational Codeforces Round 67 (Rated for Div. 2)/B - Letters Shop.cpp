#include<bits/stdc++.h>
using namespace std;
#define maxn 200005
char s[maxn],s1[maxn];
int fi[27],nex[maxn],la[27],la1[27];
inline void add(int x,int w){
	nex[la[w]]=x,la[w]=x;
	if(!fi[w])fi[w]=x;
}
inline void Nex(int w){
	if(!la1[w])la1[w]=fi[w];
	else la1[w]=nex[la1[w]];
}
int main(){
	int r,m;scanf("%d%s%d",&r,s,&m);
	for(int i=0;s[i];i++)add(i+1,s[i]-'a');
	for(int i=0;i<m;i++){
		scanf("%s",s1);memset(la1,0,sizeof(la1));
		for(int j=0;s1[j];j++){
			Nex(s1[j]-'a');
		}int ans=0;
		for(int i=0;i<26;i++)ans=max(ans,la1[i]);
		printf("%d\n",ans);
	}
	return 0;
}
