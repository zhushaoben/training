#include<bits/stdc++.h>
using namespace std;
void work(){
	int n,s,t;scanf("%d%d%d",&n,&s,&t);
	printf("%d\n",n+1-min(s,t));
}
int main(){
	int t;scanf("%d",&t);
	while(t--)work();
	return 0;
} 

