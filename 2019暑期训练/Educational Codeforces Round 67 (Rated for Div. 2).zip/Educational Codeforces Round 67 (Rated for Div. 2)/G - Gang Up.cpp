#include<bits/stdc++.h>
using namespace std;
#define maxn 5100
struct Edge{
	int next,to,fl,w;
}edge[2600005];
int fi[maxn],se=1,s=maxn-1,t=maxn-2;
inline void add_edge(int u,int v,int fl,int w){
	edge[++se].fl=fl,edge[se].next=fi[u],edge[se].to=v,edge[se].w=w,fi[u]=se,
	edge[++se].fl=0,edge[se].next=fi[v],edge[se].to=u,edge[se].w=-w,fi[v]=se;
}
int dis[maxn],flow[maxn],pre[maxn];bool vis[maxn]; 
bool SPFA(){
    deque<int> q;int sum=0,tot=0;
    memset(dis,0x3f,sizeof(dis)),memset(vis,0,sizeof(vis));
    q.push_back(s),vis[s]=1,dis[s]=0,flow[s]=0x3f3f3f3f,flow[t]=0;
    while(!q.empty()){
        int u=q.front();q.pop_front();
        if(dis[u]*tot>sum){//LLL�Ż� 
            q.push_back(u);continue;
        }
        vis[u]=0,sum-=dis[u],tot--;
        for(int i=fi[u];i;i=edge[i].next){
            int v=edge[i].to;
            if(edge[i].fl&&dis[v]>dis[u]+edge[i].w){
                dis[v]=dis[u]+edge[i].w,flow[v]=min(flow[u],edge[i].fl),pre[v]=i;//pre[i]��¼·���ϵ����i�ıߵı��
                if(vis[v])continue;
                vis[v]=1,sum+=dis[v],tot++;
                if(q.empty()||dis[v]>dis[q.front()])q.push_back(v);//SLF�Ż� 
                else q.push_front(v);
            }
        }
    }
    if(flow[t]){//����·���ϵıߵ�ʣ������ 
        for(int i=pre[t];i;i=pre[edge[i^1].to]){
            edge[i].fl-=flow[t],edge[i^1].fl+=flow[t];
        }
    }
    return flow[t];
}
int main(){
	int n,m,k,c,d,x;scanf("%d%d%d%d%d",&n,&m,&k,&c,&d);
	for(int i=0;i<k;i++){
		scanf("%d",&x);add_edge(s,x,1,0);
	}
	int u,v;
	for(int i=0;i<100;i++)add_edge(1+i*n,t,k,i*c);
	for(int i=0;i<m;i++){
		scanf("%d%d",&u,&v);
		for(int i=0;i<100;i++)for(int j=0;j<k;j++)add_edge(u+n*i,v+n*(i+1),1,(j<<1|1)*d);
		for(int i=0;i<100;i++)for(int j=0;j<k;j++)add_edge(v+n*i,u+n*(i+1),1,(j<<1|1)*d);
	}
	for(int i=1;i<=n;i++)for(int j=0;j<100;j++)add_edge(i+n*j,i+n*(j+1),k,0);
	int ans=0;
	while(SPFA())
	ans+=flow[t]*dis[t];
	printf("%d\n",ans);
	return 0;
} 
