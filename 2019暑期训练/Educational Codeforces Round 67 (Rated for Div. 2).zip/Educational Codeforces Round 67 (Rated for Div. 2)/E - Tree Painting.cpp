#include<bits/stdc++.h>
using namespace std;
#define maxn 200005
#define LL long long
struct Edge{
	int next,to;
}edge[maxn*2];
int fi[maxn],se,Si[maxn];
LL f[maxn],ans;
inline void add_edge(int u,int v){
	edge[++se].next=fi[u],fi[u]=se,edge[se].to=v,
	edge[++se].next=fi[v],fi[v]=se,edge[se].to=u;
}
void dfs(int x,int fa){
	Si[x]=1;
	for(int i=fi[x];i;i=edge[i].next){
		int v=edge[i].to;
		if(v!=fa)dfs(v,x),Si[x]+=Si[v],f[x]+=f[v];
	}
	f[x]+=Si[x];
}
void dfs1(int x,int fa){
	if(fa)f[x]=f[fa]-Si[x]*2+Si[1];ans=max(ans,f[x]);
	for(int i=fi[x];i;i=edge[i].next){
		int v=edge[i].to;
		if(v!=fa)dfs1(v,x);
	}
}
int main(){
	int n,u,v;scanf("%d",&n);
	for(int i=1;i<n;i++)scanf("%d%d",&u,&v),add_edge(u,v);
	dfs(1,0),ans=f[1];dfs1(1,0);
	printf("%lld",ans);
	return 0;
}
