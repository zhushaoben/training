#include<bits/stdc++.h>
using namespace std;
#define maxn 1005
struct A{
	int l,r;
	bool operator < (const A &a)const{
		return l<a.l;
	}
}a[maxn],b[maxn];
int s1,s2,x[maxn];
int main(){
	int n,m,t,l,r,j;scanf("%d%d",&n,&m);
	for(int i=0;i<m;i++){
		scanf("%d%d%d",&t,&l,&r);
		if(t==1)a[++s1].l=l,a[s1].r=r;
		else b[++s2].l=l,b[s2].r=r;
	}
	sort(a+1,a+s1+1);x[0]=n+1;l=r=0;
	for(int i=1;i<=s1;i++){
		if(a[i].l<=r)r=max(a[i].r,r);
		else{
			if(l)x[l]=x[l-1]-1;
			for(j=l+1;j<=r;j++)x[j]=x[j-1];
			for(j=r+1;j<a[i].l;j++)x[j]=x[j-1]-1;
			l=a[i].l,r=a[i].r;
		}
	}
	if(l)x[l]=x[l-1]-1;
	for(j=l+1;j<=r;j++)x[j]=x[j-1];
	for(j=r+1;j<=n;j++)x[j]=x[j-1]-1;
	for(int i=1;i<=s2;i++){
		if(x[b[i].l]==x[b[i].r]){
			puts("NO");return 0;
		}
	}
	puts("YES");
	for(int i=1;i<=n;i++)printf("%d ",x[i]);
	return 0;
}
