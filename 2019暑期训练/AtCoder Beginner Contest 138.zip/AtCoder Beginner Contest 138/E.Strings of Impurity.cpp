#include<bits/stdc++.h>
using namespace std;
#define maxn 100005
char s[maxn];
int num[26][maxn],L;
int main(){
	scanf("%s",s+1);
	for(int i=1;s[i];i++)num[s[i]-'a'][i]++;
	for(int i=1;s[i];i++)for(int j=0;j<26;j++)num[j][i]+=num[j][i-1];
	L=strlen(s+1);int now=0,l1=0;
	scanf("%s",s+1);
	for(int i=1;s[i];i++){
		int x=s[i]-'a';
		while(num[x][L]-num[x][l1]<=0){
			if(num[x][L]<=0){
				puts("-1");return 0;
			}
			now++,l1=0;
		}
		int r=L,l=l1+1,mid;
		while(l<=r){
			mid=(l+r)>>1;
			if(num[x][mid]-num[x][l1]>0)r=mid-1;
			else l=mid+1;
		}
		l1=l;
	}
	printf("%lld\n",1ll*now*L+l1);
	return 0;
}
