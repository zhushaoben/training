#include<bits/stdc++.h>
using namespace std;
#define maxn 100
int a[maxn];
int main(){
	int n;scanf("%d",&n);
	for(int i=0;i<n;i++)scanf("%d",a+i);
	sort(a,a+n);
	double ans=a[0];
	for(int i=1;i<n;i++){
		(ans+=a[i])/=2;
	}
	printf("%lf",ans);
	return 0;
}
