#include<bits/stdc++.h>
using namespace std;
int main(){
	int n,x;scanf("%d",&n);
	double ans=0;
	for(int i=0;i<n;i++){
		scanf("%d",&x),ans+=1.0/x;
	}
	printf("%.10lf",1/ans);
	return 0;
}
