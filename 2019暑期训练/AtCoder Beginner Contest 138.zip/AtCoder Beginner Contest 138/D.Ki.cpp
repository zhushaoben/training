#include<bits/stdc++.h>
using namespace std;
#define maxn 200005
struct Edge{
	int next,to;
}edge[maxn*2];
int fi[maxn],se,num[maxn];
inline void add_edge(int u,int v){
	edge[++se].next=fi[u],edge[se].to=v,fi[u]=se,
	edge[++se].next=fi[v],edge[se].to=u,fi[v]=se;
}
void dfs(int x,int fa){
	num[x]+=num[fa];
	for(int i=fi[x];i;i=edge[i].next){
		int v=edge[i].to;
		if(v==fa)continue;
		dfs(v,x);
	}
}
int main(){
	int n,q,u,v;scanf("%d%d",&n,&q);
	for(int i=1;i<n;i++)scanf("%d%d",&u,&v),add_edge(u,v);
	for(int i=0;i<q;i++)scanf("%d%d",&u,&v),num[u]+=v;
	dfs(1,0);
	for(int i=1;i<=n;i++)printf("%d ",num[i]);
	return 0;
} 
