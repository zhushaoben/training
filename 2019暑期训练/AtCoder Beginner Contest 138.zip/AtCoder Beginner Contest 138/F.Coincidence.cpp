#include<bits/stdc++.h>
using namespace std;
#define LL long long
#define mo 1000000007
LL L,R;int f[61][2][2][2];
int cal(int x,int a,int b,int c){
	/* a��ʾǰ���Ƿ���ĳλx>L
		b��ʾ�Ƿ���ĳλy<R
		c��ʾǰ���Ƿ���1 
	*/
	if(x<0)return 1;
	if(f[x][a][b][c])return f[x][a][b][c];
	int l=(L>>x)&1,r=(R>>x)&1,&ans=f[x][a][b][c];
	if(a)l=0;if(b)r=1;
	for(int i=l;i<2;i++)for(int j=i;j<=r;j++){
		if(c)(ans+=cal(x-1,a|(i>l),b|(j<r),c))%=mo;
		else if((i^j)==0)(ans+=cal(x-1,a|(i>l),b|(j<r),(i==1)))%=mo;
	}
	return ans;
}
int main(){
	scanf("%lld%lld",&L,&R);
	printf("%d",cal(60,0,0,0));
	return 0;
} 
