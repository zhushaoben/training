#include<bits/stdc++.h>
using namespace std;
int main(){
	int n,ma=0,pre=0,pre1=0,x;scanf("%d",&n);
	for(int i=0;i<n;i++){
		scanf("%d",&x);
		if(pre>pre1&&pre>x){
			if(ma){puts("NO");return 0; }
			ma=pre;
		}
		pre1=pre,pre=x;
	}
	x=0;if(pre>pre1&&pre>x){
			if(ma){puts("NO");return 0; }
			ma=pre;
		}
		puts("YES");
	return 0;
}
