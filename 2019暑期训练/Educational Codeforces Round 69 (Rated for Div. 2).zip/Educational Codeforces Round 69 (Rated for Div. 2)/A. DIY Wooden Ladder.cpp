#include<bits/stdc++.h>
using namespace std;
#define maxn 100005
int a[maxn];
void work(){
	int n;scanf("%d",&n);
	for(int i=0;i<n;i++)scanf("%d",a+i);
	sort(a,a+n);
	int ans=min(a[n-2]-1,n-2);
	printf("%d\n",ans);
}
int main(){
	int t ;scanf("%d",&t);
	while(t--)work();
	return 0;
} 
