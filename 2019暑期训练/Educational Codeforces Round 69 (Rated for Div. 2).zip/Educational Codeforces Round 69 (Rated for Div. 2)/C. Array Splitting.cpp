#include<bits/stdc++.h>
using namespace std;
#define maxn 300005
int a[maxn];
long long ans=0;
int main(){
	int n,k;scanf("%d%d",&n,&k);k=n-k;
	for(int i=0;i<n;i++){
		scanf("%d",a+i);
	}
	for(int i=n-1;~i;i--)a[i+1]-=a[i];
	sort(a+1,a+n);
	for(int i=1;i<=k;i++)ans+=a[i];
	printf("%lld\n",ans);
	return 0;
}
