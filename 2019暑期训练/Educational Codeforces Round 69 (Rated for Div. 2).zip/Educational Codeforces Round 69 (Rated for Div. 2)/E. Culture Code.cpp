#include<bits/stdc++.h>
using namespace std;
#define maxn 200005
#define LL long long
#define inf 0x3fffffff
#define mo 1000000007
#define N 1e9
struct Node{
	int in,out;
	bool operator < (const Node& b)const{
		if(in!=b.in)return in>b.in;
		return out>b.out;
	}
}a[maxn];
struct Tree{
	int l,r,mi,num;	
}tr[maxn*30];
int L,si,root,ans=inf,ans1,a1,b1,f[maxn],f1[maxn];
void update(int &a,int &b,int c,int d){
	if(a>c)a=c,b=d;
	else if(a==c)(b+=d)%=mo;
	return;
}
void change(int l,int r,int &x){
	if(!x)x=++si,tr[x].mi=inf;
	if(l==r){
		update(tr[x].mi,tr[x].num,a1,b1);
		return;
	}
	int mid=(l+r)>>1;tr[x].mi=inf;
	if(L<=mid)change(l,mid,tr[x].l);
	else change(mid+1,r,tr[x].r);
	if(tr[x].l)update(tr[x].mi,tr[x].num,tr[tr[x].l].mi,tr[tr[x].l].num);
	if(tr[x].r)update(tr[x].mi,tr[x].num,tr[tr[x].r].mi,tr[tr[x].r].num);
	
}
void query(int l,int r,int x){
	if(!x)return;
	if(L<=l){
		update(a1,b1,tr[x].mi,tr[x].num);
		return;
	}
	int mid=(l+r)>>1;
	if(L<=mid)query(l,mid,tr[x].l);
	query(mid+1,r,tr[x].r);
}
int main(){
	int n;scanf("%d",&n);
	for(int i=1;i<=n;i++)scanf("%d%d",&a[i].out,&a[i].in);
	sort(a+1,a+n+1);int maxi=a[1].in;
	for(int i=1;i<=n;i++){
		if(maxi<a[i].out)f[i]=a[i].in,f1[i]=1;
		else L=a[i].out,a1=inf,query(1,maxi,root),f[i]=a1-(a[i].out-a[i].in),f1[i]=b1;
		a1=f[i],b1=f1[i];L=a[i].in,change(1,maxi,root);
	}
	for(int i=1;i<=n;i++){
		update(ans,ans1,f[i],f1[i]);
	}
	printf("%d\n",ans1);
	return 0;
}
