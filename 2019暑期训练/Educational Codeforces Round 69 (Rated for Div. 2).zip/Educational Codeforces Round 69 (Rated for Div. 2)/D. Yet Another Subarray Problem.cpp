#include<bits/stdc++.h>
using namespace std;
#define maxn 300005
#define LL long long
int a[maxn];
int main(){
	int n,m,k;scanf("%d%d%d",&n,&m,&k);
	for(int i=0;i<n;i++)scanf("%d",a+i);
	LL ans=0;
	for(int i=0;i<m;i++){
		LL mi=0,now=0;
	for(int j=0;j<n;j++){
		now+=a[j];
		ans=max(ans,now-mi-k);
		if(j%m==i)now-=k;
		mi=min(mi,now);
	}
	}
	
	printf("%lld\n",ans);
	return 0;
}
