#include<bits/stdc++.h>
using namespace std;
#define maxn 100005
int a[maxn],b[maxn];
int main(){
	int n,w;scanf("%d",&n);
	long long ans=0;
	for(int i=0;i<=n;i++){
		scanf("%d",a+i);
	}
	for(int i=1;i<=n;i++){
		scanf("%d",b+i);
		w=min(a[i-1],b[i]),b[i]-=w,ans+=w;
		w=min(a[i],b[i]),a[i]-=w,ans+=w;
	}
	printf("%lld\n",ans);
	return 0;
}
