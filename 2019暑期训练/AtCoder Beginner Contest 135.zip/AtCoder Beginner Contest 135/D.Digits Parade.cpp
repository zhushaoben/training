#include<bits/stdc++.h>
using namespace std;
#define maxn 100005
#define mo 1000000007
char s[maxn];
int f[maxn][13];
int main(){
	scanf("%s",s);f[0][0]=1;
	int i;
	for(i=0;s[i];i++){
		if(s[i]=='?'){
			for(int j=0;j<13;j++){
				for(int x=0;x<10;x++){
					(f[i+1][(j*10+x)%13]+=f[i][j])%=mo;
				}
			}
		}
		else{
			int x=s[i]-'0';
			for(int j=0;j<13;j++){
				(f[i+1][(j*10+x)%13]+=f[i][j])%=mo;
			}
		}
	}
	printf("%d\n",f[i][5]);
	return 0;
} 
