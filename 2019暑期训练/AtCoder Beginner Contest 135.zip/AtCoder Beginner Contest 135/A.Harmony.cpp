#include<bits/stdc++.h>
using namespace std;
int main(){
	int a,b;scanf("%d%d",&a,&b),a+=b;
	if(a&1)puts("IMPOSSIBLE");
	else printf("%d\n",a>>1);
	return 0;
} 
