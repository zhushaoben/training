#include<bits/stdc++.h>
using namespace std;
int a[100],b[100];
int main(){
	int n,w=0;scanf("%d",&n);
	for(int i=0;i<n;i++)scanf("%d",a+i),b[i]=a[i];sort(a,a+n);
	for(int i=0;i<n;i++)if(b[i]!=a[i])w++;
	if(w<=2)puts("YES");
	else puts("NO");
	return 0;
}
