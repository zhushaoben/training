#include<bits/stdc++.h>
using namespace std;
#define x first
#define y second
typedef pair<int,int> pi;
int k,x,y,t;
pi a[200020];
pi cal(int x,int y){
	if (x>y){
		pi t=cal(y,x);
		return {t.y,t.x};
	}
	if (x<0){
		pi t=cal(-x,y);
		return {-t.x,t.y};
	}
	if (x+y>=2*k) return {x,y-k};
	if (x+y==k) return {0,0};
	int t=k-(x+y)/2;
	return {-t,y-k+x+t};
}
int main(){
	scanf("%d%d%d",&k,&x,&y);
	if (!(k&1) && (x+y)&1) return puts("-1"),0;
	a[0]={x,y};
	for (;a[t].x || a[t].y;t++) a[t+1]=cal(a[t].x,a[t].y);
	printf("%d\n",t);
	for (;t--;) printf("%d %d\n",a[t].x,a[t].y);
}
